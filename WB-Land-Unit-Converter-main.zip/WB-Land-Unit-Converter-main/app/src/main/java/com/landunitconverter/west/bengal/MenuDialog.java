package com.landunitconverter.west.bengal;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MenuDialog {
    public MenuDialog(Activity activity) {
        // Inflate the custom layout
        View dialogView = LayoutInflater.from(activity).inflate(R.layout.dialog_menu, null);

        // Create the Material 3 dialog
        AlertDialog dialog = new MaterialAlertDialogBuilder(activity)
                .setView(dialogView)
                .setCancelable(true)
                .create();


        // Get references to your CardViews
        CardView shareBtn = dialogView.findViewById(R.id.shareBtn);
        CardView rateBtn = dialogView.findViewById(R.id.rateBtn);
        CardView languageBtn = dialogView.findViewById(R.id.languageBtn);

        String appDownloadLink = "https://play.google.com/store/apps/details?id=" + activity.getPackageName();

        shareBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");

            // Create the message
            String shareBody = "Check out this app: " + appDownloadLink;
            String shareSub = "App Recommendation"; // Optional subject for emails

            intent.putExtra(Intent.EXTRA_SUBJECT, shareSub);
            intent.putExtra(Intent.EXTRA_TEXT, shareBody);

            // Launch the chooser (Share Dialog)
            activity.startActivity(Intent.createChooser(intent, "Share using"));

            dialog.dismiss();
        });

        rateBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(appDownloadLink));
            activity.startActivity(intent);
            dialog.dismiss();
        });

        languageBtn.setOnClickListener(v -> {
            // 1. Create a Popup Menu attached to the button
            PopupMenu popup = new PopupMenu(activity, languageBtn);

            // 2. Add Language Options manually
            popup.getMenu().add(0, 1, 0, "English");
            popup.getMenu().add(0, 2, 0, "বাংলা");

            // 3. Handle Clicks
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == 1) {
                    CommonMethods.setAppLocaleLanguage("en"); // Switch to English
                } else if (item.getItemId() == 2) {
                    CommonMethods.setAppLocaleLanguage("bn"); // Switch to Bengali
                }
                return true;
            });

            popup.show();
        });

        // Show the dialog
        dialog.show();

        // Set dialog width to match parent (optional)
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT
            );
        }
    }
}
