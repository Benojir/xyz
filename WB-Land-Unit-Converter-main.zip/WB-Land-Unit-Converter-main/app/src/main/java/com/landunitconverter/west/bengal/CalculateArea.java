package com.landunitconverter.west.bengal;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class CalculateArea {

    private final Context context;

    private final String languageCode = CommonMethods.getCurrentLanguageCode();
    public CalculateArea(Context context) {
        this.context = context;
    }

    // 1. Define Unit Names in order matching the spinner

    // 2. Define Conversion Factors: How many "Shataks" are in 1 Unit?
    // Example: 1 Katha = 1.65 Shatak, so index 1 is 1.65
    // Example: 1 Shatak = 435.6 SqFt, so 1 SqFt = 1/435.6 Shatak
    private static final double[] TO_SHATAK_FACTORS = {
            1.0,                // 0. Shatak
            1.65,               // 1. Katha
            33.0,               // 2. Bigha
            100.0,              // 3. Acre
            247.105,            // 4. Hectare
            0.7856972,          // 5. Ana
            1.0 / 435.6,        // 6. SqFeet
            1.0 / 40.47,        // 7. SqMeter
            1.0 / 0.00004047,   // 8. SqKM (Matches your SqMeter logic)
            64000.0             // 9. SqMile (Exact: 640 Acres * 100)
    };

    public JSONArray calculate(int spinnerPosition, Double landValue) throws JSONException {

        String[] UNIT_NAMES = context.getResources().getStringArray(R.array.units_array);

        JSONArray calculatedData = new JSONArray();
//        DecimalFormat df = new DecimalFormat("##.####");
        DecimalFormat df = new DecimalFormat("0.####");

        // Step 1: Convert the input value to the Base Unit (Shatak)
        double valueInShatak = landValue * TO_SHATAK_FACTORS[spinnerPosition];

        // Step 2: Loop through all units and convert from Shatak to Target
        for (int i = 0; i < UNIT_NAMES.length; i++) {

            if (spinnerPosition == i) {
                continue;
            }
            // Formula: Target = (Value in Shatak) / (Target Factor)
            double convertedValue = valueInShatak / TO_SHATAK_FACTORS[i];

            // Format the output
            String formattedOutput = df.format(convertedValue);
            String formattedInput = df.format(landValue);

            // Construct the String: "InputVal InputUnit = OutputVal OutputUnit"
            String result = formattedInput + " " + UNIT_NAMES[spinnerPosition] + " = " + formattedOutput + " " + UNIT_NAMES[i];

//            String result = formattedValue + " " + UNIT_NAMES[i];

            if (languageCode.equalsIgnoreCase("bn")) {
                result = CommonMethods.convertToBengali(result);
            }

            JSONObject resultData = new JSONObject();
            resultData.put("unit_name", UNIT_NAMES[i]);
            resultData.put("result_value", formattedOutput);
            resultData.put("input_value", landValue);
            resultData.put("formatted_text", result);

            calculatedData.put(resultData);
        }

        return calculatedData;
    }
}