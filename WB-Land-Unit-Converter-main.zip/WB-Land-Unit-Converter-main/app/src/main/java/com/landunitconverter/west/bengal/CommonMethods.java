package com.landunitconverter.west.bengal;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;

import java.util.Locale;

public class CommonMethods {

    public static String convertToEnglish(String input) {
        return input
                .replace("০", "0")
                .replace("১", "1")
                .replace("২", "2")
                .replace("৩", "3")
                .replace("৪", "4")
                .replace("৫", "5")
                .replace("৬", "6")
                .replace("৭", "7")
                .replace("৮", "8")
                .replace("৯", "9");
    }

    public static String convertToBengali(String input) {
        return input
                .replace("0", "০")
                .replace("1", "১")
                .replace("2", "২")
                .replace("3", "৩")
                .replace("4", "৪")
                .replace("5", "৫")
                .replace("6", "৬")
                .replace("7", "৭")
                .replace("8", "৮")
                .replace("9", "৯");
    }

    public static String getCurrentLanguageCode() {
        LocaleListCompat locales = AppCompatDelegate.getApplicationLocales();

        // 1. Check if the list has items
        if (!locales.isEmpty()) {
            // 2. Get the first locale safely
            Locale firstLocale = locales.get(0);

            // 3. Check for null before accessing properties
            if (firstLocale != null) {
                return firstLocale.getLanguage();
            }
        }

        // Fallback to system default if app-specific locale is not set or is null
        return Locale.getDefault().getLanguage();
    }

    public static void setAppLocaleLanguage(String languageCode) {
        LocaleListCompat appLocale = LocaleListCompat.forLanguageTags(languageCode);
        AppCompatDelegate.setApplicationLocales(appLocale);
    }
}
