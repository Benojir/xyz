package com.landunitconverter.west.bengal;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.graphics.Insets;
import androidx.core.os.LocaleListCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.landunitconverter.west.bengal.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        // 1. Check if a language is already set
        if (AppCompatDelegate.getApplicationLocales().isEmpty()) {
            // 2. If no language is set, FORCE Bengali
            LocaleListCompat bengali = LocaleListCompat.forLanguageTags("bn");
            AppCompatDelegate.setApplicationLocales(bengali);
        }
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        binding.menuBtn.setOnClickListener(v -> new MenuDialog(MainActivity.this));

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.units_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.unitSpinner.setAdapter(adapter);


        binding.unitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                convertToUnits(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        binding.amountInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                int position = binding.unitSpinner.getSelectedItemPosition();
                convertToUnits(position);
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        });

        binding.clearBtn.setOnClickListener(v -> binding.amountInput.setText(""));
    }

    private void convertToUnits(int position) {
        try {
            String inputValueStr = binding.amountInput.getText().toString().trim().replace(" ", "");

            if (inputValueStr.isEmpty()) {
                binding.clearBtn.setVisibility(INVISIBLE);
                return;
            } else {
                binding.clearBtn.setVisibility(VISIBLE);
            }

            Double inputValue = Double.parseDouble(inputValueStr);
            setRecyclerView(position, inputValue);
        } catch (Exception e) {
            Toast.makeText(this, "Error conversion", Toast.LENGTH_SHORT).show();
            Log.e("MainActivity", "convertToUnits: ", e);
        }
    }

    private void setRecyclerView(int position, Double landValue) throws JSONException {
        CalculateArea calculateArea = new CalculateArea(this);
        JSONArray data = calculateArea.calculate(position, landValue);

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, data);
        binding.recyclerView.setAdapter(adapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        binding.recyclerView.setLayoutManager(linearLayoutManager);
    }
}